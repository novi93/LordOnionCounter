Simple Talk article demo code using the .NET MemoryMappedFile.
