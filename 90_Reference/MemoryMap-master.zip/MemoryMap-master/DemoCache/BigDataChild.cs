﻿using System;

namespace DemoCache
{
    [Serializable]
    public class BigDataChild
    {
        public int Id { get; set; }
        public double SomeDouble { get; set; }
        public string SomeString { get; set; }
    }
}
